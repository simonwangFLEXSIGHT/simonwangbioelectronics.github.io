Zimeng Wang (Simon) — Postdoctoral Research Portfolio V8

Open index.html directly in a modern browser. No installation or server is needed.
All page images, English CV downloads and patent PDF are embedded in the HTML.
The assets/ and downloads/ folders contain separate copies for editing and reuse.
Research figures: click to enlarge, select Original size, or Save image.
Animations: Pause motion; system reduced-motion preferences are respected.
Hero waveform animation is illustrative, not a real-time recording.
Email and DOI links require an email application or internet access.

Based on the complete V7 source; research sections and original images retained.
Six publications restored from the original portfolio and supplied CV.
The English CV is the recovered complete version, updated for name and identity.
Chinese CV is retained unchanged. Publication metadata and research status follow supplied materials.
